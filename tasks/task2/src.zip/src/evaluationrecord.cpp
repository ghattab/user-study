#include "evaluationrecord.h"


using namespace std;

Measurement::Measurement(Vec3f coord,
             Vec4f quad,
             QDateTime date,
             int phase,
             QTime elapsed_time):
    m_Coord(coord),
    m_Quad(quad),
    m_Date(date),
    m_Phase(phase),
    m_Ellapsed_time(elapsed_time)
{

}

EvaluationRecord::EvaluationRecord(int id):
    m_ID(id)
{
    measures = new vector<Measurement*>();
}

int EvaluationRecord::get_ID()
{
	return m_ID;
}

Measurement *EvaluationRecord::get_meassurment(int phase)
{
    auto m = std::find_if(measures->begin(),
            measures->end(),
            [phase](Measurement *x){return phase == x->m_Phase;});
    return m != measures->end() ? *m : nullptr;
}
bool EvaluationRecord::push_meassurment(Measurement *m){

}
