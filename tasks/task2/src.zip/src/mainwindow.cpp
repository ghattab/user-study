#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QString>
#include <QTimer>
#include <QStandardItemModel>
#include <QMessageBox>
#include <QTextStream>
#include <QFileInfo>
#include <set>
#include <iterator>
#include <cv.h>
#include <igstkPulseGenerator.h>

#include "PolarisObject.h"

UserEvaluationPolaris::UserEvaluationPolaris(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    //Status Participant disabled
    // to be enabled when polaris works, registration is loaded, data is loaded
    ui->tabWidget->setTabEnabled(ui->tabWidget->indexOf(ui->participantTab), false);

    this->snapshot = false;
    this->timer = new QTimer(this);
    connect(this->timer, SIGNAL(timeout()), this, SLOT(update_igstk()));
    this->timer->start(0);

    this->snapshotShortcut = new QShortcut(
                Qt::Key_Space, this,
                SLOT(on_recordMeasurement()));
    this->startRecordingShortcut = new QShortcut(
                Qt::Key_S, this,
                SLOT(on_startRecording()));
    this->snapshotShortcut->setEnabled(false);
    this->startRecordingShortcut->setEnabled(false);
    this->snapshotCnt = 0;
    this->finished_phases.clear();
    this->cached_finished_phases.clear();

    m_Configfilepath = "/";

    loggerFile.open("log.txt");
    logger = igstk::Object::LoggerType::New();
    logOutput = itk::StdStreamLogOutput::New();
    logOutput->SetStream(loggerFile);
    logger->AddLogOutput(logOutput);
    logger->SetPriorityLevel(itk::Logger::DEBUG);

    this->loadConfig(this->config);
}

UserEvaluationPolaris::~UserEvaluationPolaris()
{
    this->saveConfig(this->config);
    delete this->timer;
    delete this->startRecordingShortcut;
    delete this->snapshotShortcut;
    delete ui;

    if(this->m_UserEvaluationPipeline)
        this->m_UserEvaluationPipeline->Stop();
    if(this->m_SceneUpdate)
        this->m_SceneUpdate->Stop();
    if(this->m_Polaris)
        this->m_Polaris->Stop();

    loggerFile.close();
}

void UserEvaluationPolaris::update_igstk()
{
    igstk::PulseGenerator::CheckTimeouts();

    if (this->snapshot) {
        int errorcode = this->m_UserEvaluationPipeline->snapshotSuccessfull();
        if (errorcode == 0) {
            return;
        } else if(errorcode == 1) {
            if (++snapshotCnt >= this->num_snapshot){
                this->m_UserEvaluationPipeline->stopTracking();
                //deactivate shortcut and button
                this->snapshotShortcut->setEnabled(false);
                ui->recordMeasurementButton->setEnabled(false);
                ui->stopRecordingMeasurementsButton->setEnabled(false);
                ui->recordingsButtonBox->setEnabled(true);
                ui->choosePhaseDropbox->setEnabled(true);
                ui->nextPhaseButton->setEnabled(true);

                this->snapshotCnt = 0;
                int cur_phase = ui->choosePhaseDropbox->currentIndex();
                this->cached_finished_phases.insert(cur_phase);
                ui->messageTextBrowser->append("Phase " + QString::number(++cur_phase) +" completed!");
            }
        } else if (errorcode == 2) {
            ui->messageTextBrowser->append("Pointer not in sight of Polaris");
        } else if (errorcode == 4) {
            ui->messageTextBrowser->append("Object not in sight of Polaris");
        } else if (errorcode == 8) {
            ui->messageTextBrowser->append("Pointer too close to previous Measurement");
        }
        this->snapshot = false;
    }
}


void UserEvaluationPolaris::loadConfig(QString config_fn)
{
    QFile configFile(config_fn);
    if(configFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QByteArray content = configFile.readLine();
        QList<QByteArray> split_list = content.split(',');
        auto itr = split_list.begin();
        ui->contDataPathLineEdit->setText(*itr++);
        ui->CSVdataPathLineEdit->setText(*itr++);
        ui->object1ConfigFileLineEdit->setText(*itr++);
        ui->object2ConfigFileLineEdit->setText(*itr++);
        ui->pointerConfigFileLineEdit->setText(*itr++);
        int button_id = itr++->toInt();
        QAbstractButton *button = ui->chooseCommunicationTypeButtonGroup->button(button_id);
        if (button != 0)
            button->setChecked(true);
        ui->ethernetHostnameLineEdit->setText(*itr++);
        int ethernet_port = itr++->toInt();
        ui->ethernetPortSpinBox->setValue(ethernet_port);
        int serial_port = itr++->toInt();
        ui->serialPortSpinBox->setValue(serial_port);
        int minDist = itr++->toInt();
        ui->minDistanceSpinBox->setValue(minDist);
        ui->messageTextBrowser->append("Configuration file loaded from " + config_fn);
    } else {
        //Fill hostname
        ui->ethernetHostnameLineEdit->setText(DEFAULT_POLARIS_HOSTNAME);
        //Fill Port
        ui->ethernetPortSpinBox->setValue(DEFAULT_POLARIS_PORT);
        //Fill Port
        ui->serialPortSpinBox->setValue(DEFAULT_POLARIS_SERIAL_PORT);
        ui->messageTextBrowser->append("Set Default Configuration");
    }
    configFile.close();
}


void UserEvaluationPolaris::saveConfig(QString config_fn)
{
    QFile configFile(config_fn);
    configFile.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream stream(&configFile);
    stream << ui->contDataPathLineEdit->text() << ",";
    stream << ui->CSVdataPathLineEdit->text() << ",";
    stream << ui->object1ConfigFileLineEdit->text() << ",";
    stream << ui->object2ConfigFileLineEdit->text() << ",";
    stream << ui->pointerConfigFileLineEdit->text() << ",";
    stream << QString::number(ui->chooseCommunicationTypeButtonGroup->checkedId()) << ",";
    stream << ui->ethernetHostnameLineEdit->text() << ",";
    stream << QString::number(ui->ethernetPortSpinBox->value()) << ",";
    stream << QString::number(ui->serialPortSpinBox->value())  << ",";
    stream << QString::number(ui->minDistanceSpinBox->value());
    configFile.close();
    ui->messageTextBrowser->append("Config saved to " + config_fn);
}

// SETUP


//void UserEvaluationPolaris::on_resetButton_clicked()
//{
//    //TODO: stop any connection with polaris like we can't delete the pipeline objects to reset themŝ
//    this->m_UserEvaluationPipeline->Stop();
//    this->m_SceneUpdate->Stop();
//    this->m_Polaris->Stop();

//    this->m_SceneUpdate->GetObject(this->m_IDPointer)->SetColor(0,0,0);

//    ui->resetButton->setEnabled(false);
//    ui->connectButton->setEnabled(true);
//    ui->tabWidget->setTabEnabled(ui->tabWidget->indexOf(ui->participantTab), false);
//    ui->messageTextBrowser->append("Reset Connection");
//}

void UserEvaluationPolaris::on_connectButton_clicked()
{

    this->m_Polaris = MediAssist::PolarisObject::New();
    this->m_Polaris->SetThreadingEnabled(true);
    this->m_Polaris->SetFrequency(5);
    this->m_Polaris->SetLogger(logger);
    this->m_Polaris->SetPolarisPort(DEFAULT_POLARIS_SERIAL_PORT);
    this->m_Polaris->SetSocketPolarisHostnamePort(
                DEFAULT_POLARIS_HOSTNAME.toStdString(), DEFAULT_POLARIS_PORT);


    //TODO: connect to polaris according to the settings
    if(ui->chooseCommunicationTypeButtonGroup->checkedButton() == ui->chooseEthernetRadioButton) {
        this->m_Polaris->SetSocketPolarisHostnamePort(
                    ui->ethernetHostnameLineEdit->text().toStdString(),
                    ui->ethernetPortSpinBox->value());
        this->m_Polaris->SetCommunicationType(MediAssist::PolarisObject::NDI_COMMUNICATION_SOCKET);
    }
    else if(ui->chooseCommunicationTypeButtonGroup->checkedButton() == ui->chooseEthernetRadioButton) {
        this->m_Polaris->SetPolarisPort(ui->serialPortSpinBox->value());
        this->m_Polaris->SetCommunicationType(MediAssist::PolarisObject::NDI_COMMUNICATION_SERIAL);
    }
    else {
        ui->messageTextBrowser->append("No Communication selected.");
        return;
    }

    //will connect and call init
    ui->messageTextBrowser->append("Configure Connection to Polaris.");
    //TODO: bug when no connection available then it is stuck here
    this->m_Polaris->Configure();

    this->m_SceneUpdate = MediAssist::SceneUpdatePipeline::New();
    this->m_SceneUpdate->SetFrequency(20);
    this->m_SceneUpdate->SetLogger(logger);
    this->m_SceneUpdate->SetTracker(this->m_Polaris);

    this->m_UserEvaluationPipeline = MediAssist::UserEvaluationPipeline::New();

    ui->messageTextBrowser->append("Add Tools.");
    if(ui->pointerConfigFileLineEdit->text().isEmpty() ||
            ui->object1ConfigFileLineEdit->text().isEmpty() ||
            ui->object2ConfigFileLineEdit->text().isEmpty()) {
        ui->messageTextBrowser->append("Choose Configfile");
        return;
    }
    this->m_IDPointer = this->m_SceneUpdate->AddConfiguredTool(
                ui->pointerConfigFileLineEdit->text().toLatin1().data(),
                "Pointer", MediAssist::SOT_Ellipsoid);
    //TODO: Was ist denn das?
    this->m_SceneUpdate->GetObject(this->m_IDPointer)->SetEllipsoidParameters(5,5,5);
    std::string IDObject1 = this->m_SceneUpdate->AddConfiguredTool(
                ui->object1ConfigFileLineEdit->text().toLatin1().data(),
                "Object1", MediAssist::SOT_Ellipsoid);
    this->m_SceneUpdate->GetObject(IDObject1)->SetEllipsoidParameters(5,5,5);
    std::string IDObject2 = this->m_SceneUpdate->AddConfiguredTool(
                ui->object2ConfigFileLineEdit->text().toLatin1().data(),
                "Object2", MediAssist::SOT_Ellipsoid);
    this->m_SceneUpdate->GetObject(IDObject2)->SetEllipsoidParameters(5,5,5);
    this->m_SceneUpdate->Configure();

    //check wether lineedit is not empty and valid
    ui->messageTextBrowser->append("Configure Outputfile.");
    if(ui->contDataPathLineEdit->text().isEmpty() ||
            ui->CSVdataPathLineEdit->text().isEmpty()) {
        ui->messageTextBrowser->append("Choose datafiles");
        return;
    }

    this->m_UserEvaluationPipeline->SetContDataPathName(
                ui->contDataPathLineEdit->text().toStdString());
    this->m_UserEvaluationPipeline->SetCSVoutPathName(
                ui->CSVdataPathLineEdit->text().toStdString());
    this->m_UserEvaluationPipeline->SetToolIDs(IDObject1, IDObject2, this->m_IDPointer);
    double minDistance = static_cast<double>(ui->minDistanceSpinBox->value());
    this->m_UserEvaluationPipeline->SetMinDistance(minDistance);
    this->m_UserEvaluationPipeline->ConnectSource(this->m_SceneUpdate);
    this->m_UserEvaluationPipeline->Configure();

    this->m_SceneUpdate->GetObject(this->m_IDPointer)->SetColor(0,1,0);
    this->m_Polaris->ConnectVisibilityWidget(ui->visibilityWidget);

    ui->messageTextBrowser->append("Start Pipelines.");
    this->m_Polaris->Start();
    this->m_SceneUpdate->Start();
    if (this->m_SceneUpdate->IsRunning()){
        ui->messageTextBrowser->append("Sceneupdatepipeline is running");
    }
    else {
        ui->messageTextBrowser->append("Sceneupdatepipeline is not running");
    }
    this->m_UserEvaluationPipeline->Start();
    if (this->m_UserEvaluationPipeline->IsRunning()){
        ui->messageTextBrowser->append("UserEvaluationPipeline is running");
    }
    else {
        ui->messageTextBrowser->append("UserEvaluationPipeline is not running or does not receive data, try to restart application.");
        return;
    }
    ui->tabWidget->setTabEnabled(ui->tabWidget->indexOf(ui->participantTab), true);
    ui->connectButton->setEnabled(false);

    //ui->resetButton->setEnabled(true);
    //test

}

void UserEvaluationPolaris::on_chooseEthernetRadioButton_clicked()
{
    ui->ethernetHostnameLineEdit->setEnabled(true);
    ui->ethernetPortSpinBox->setEnabled(true);
    ui->serialPortSpinBox->setEnabled(false);
}

void UserEvaluationPolaris::on_chooseSerialRadioButton_clicked()
{
    ui->ethernetHostnameLineEdit->setEnabled(false);
    ui->ethernetPortSpinBox->setEnabled(false);
    ui->serialPortSpinBox->setEnabled(true);
}

bool fileExists(QString path) {
    QFileInfo check_file(path);
    return check_file.exists() && check_file.isFile();
}

void UserEvaluationPolaris::on_startEvaluationButton_clicked()
{
    //btw. enable according items
    ui->messageTextBrowser->append("Initialized for Participant ID: " +
                                   QString::number(ui->participantIDSpinner->value()));
    this->m_UserEvaluationPipeline->SetParticipantID(ui->participantIDSpinner->value());
    this->m_UserEvaluationPipeline->SetPhase(ui->choosePhaseDropbox->currentIndex());

    QString fn = QString::fromStdString(this->m_UserEvaluationPipeline->composeCSVoutFileName(true, false));
    if (fileExists(fn))
    {

        QFile file(fn);
        if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            while (!file.atEnd()) {
                QByteArray line = file.readLine();
                auto split_list = line.split(',');
                int phase = split_list[1].toInt();
                this->finished_phases.insert(phase - 1);
            }
        }
        file.close();
    }
    for (auto itr = this->finished_phases.begin(); itr != this->finished_phases.end(); ++itr)
        ui->messageTextBrowser->append("Phase " + QString::number(*itr + 1) + " completed!");

    this->m_UserEvaluationPipeline->openCSVdataFile();

    ui->choosePhaseDropbox->setEnabled(true);
    ui->startEvaluationButton->setEnabled(false);
    ui->participantIDSpinner->setEnabled(false);
    ui->recordingsButtonBox->setEnabled(true);
    no_records = true;
    change_num_snapshot(ui->choosePhaseDropbox->currentText());
    // enable all further
}

void UserEvaluationPolaris::backup(int phase, QString data_fn , QString backup_fn)
{
    QFile backup_file(backup_fn);
    QFile data_file(data_fn);
    QFile data_file_swp(data_fn + ".swp");
    if (backup_file.open(QIODevice::Text | QIODevice::Append) &&
            data_file.open(QIODevice::ReadOnly | QIODevice::Text) &&
            data_file_swp.open(QIODevice::WriteOnly | QIODevice::Text)) {
        //write according lines to backup file
        while (!data_file.atEnd()) {
            QByteArray line = data_file.readLine();
            auto split_list = line.split(',');
            if (phase == split_list[1].toInt()) {
                backup_file.write(line);
            }
            else {
                data_file_swp.write(line);
            }
        }
        data_file.close();
        data_file.remove();
        data_file_swp.rename(data_fn);
        data_file_swp.close();
        QFile swp (data_fn + ".swp");
        swp.remove();
        backup_file.close();
    }
    else {
        data_file.close();
        data_file_swp.close();
        backup_file.close();
        ui->messageTextBrowser->append("could not open backup oder data file.");
    }
}

void UserEvaluationPolaris::on_startRecording()
{
    int cur_phase = ui->choosePhaseDropbox->currentIndex();
    if(this->finished_phases.find(cur_phase) != this->finished_phases.end()) {
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "Duplicate",
           "Do you want to redo this Phase? Previosly captured data of this Phase will be moved to .backup file.",
           QMessageBox::Yes|QMessageBox::No);
        if (reply == QMessageBox::Yes) {
            int phase_csv = ui->choosePhaseDropbox->currentIndex() + 1;
            QString fn = QString::fromStdString(
                        this->m_UserEvaluationPipeline->composeCSVoutFileName(false, false));
            backup(phase_csv,
                   fn,
                   fn + ".backup");
            fn = QString::fromStdString(
                        this->m_UserEvaluationPipeline->composeCSVoutFileName(true, false));
            backup(phase_csv,
                   fn,
                   fn + ".backup");
            fn = QString::fromStdString(
                        this->m_UserEvaluationPipeline->composeContDataFileName(false));
            backup(phase_csv,
                   fn,
                   fn + ".backup");
            fn = QString::fromStdString(
                        this->m_UserEvaluationPipeline->composeContDataFileName(true));
            backup(phase_csv,
                   fn,
                   fn + ".backup");
            //open new backup file
        } else
            return;
    }
    if(this->cached_finished_phases.find(cur_phase) != this->cached_finished_phases.end()) {
        QMessageBox::question(this, "Duplicate phases in cache",
                   "This phase has already been measured but not saved. Please check phase or save/cancel first.",
                    QMessageBox::Ok);
        return;
    }

    ui->messageTextBrowser->append("Start Recording");
    this->m_UserEvaluationPipeline->startTracking();
    // and enable space for next recording
    this->snapshotShortcut->setEnabled(true);
    ui->recordMeasurementButton->setEnabled(true);
    ui->stopRecordingMeasurementsButton->setEnabled(true);
    ui->startRecordButton->setEnabled(false);
    this->startRecordingShortcut->setEnabled(false);
    ui->choosePhaseDropbox->setEnabled(false);
    ui->nextPhaseButton->setEnabled(false);
    no_records = false;
    this->snapshotCnt = 0;
}

void UserEvaluationPolaris::on_startRecordButton_clicked()
{
    on_startRecording();
}

void UserEvaluationPolaris::on_recordMeasurement()
{
    //TODO: test wether necessary tools can be seen
    //TODO: check wether far enough from last point
    this->m_UserEvaluationPipeline->takeSnapshot(snapshotCnt);
    this->snapshot = true;
    ui->messageTextBrowser->append("Recording measure " +
                                   QString::number(snapshotCnt+1) + " for " +
                                   ui->choosePhaseDropbox->currentText());
    if(0 == this->m_UserEvaluationPipeline->isActive() & 2)
        ui->messageTextBrowser->append("csv file not open");
    if(0 == this->m_UserEvaluationPipeline->isActive() & 4)
        ui->messageTextBrowser->append("csv raw file not open");
    if(0 == this->m_UserEvaluationPipeline->isActive() & 8)
        ui->messageTextBrowser->append("cont file not open");
    if(0 == this->m_UserEvaluationPipeline->isActive() & 16)
        ui->messageTextBrowser->append("cont raw file not open");
    if(0 == this->m_UserEvaluationPipeline->isActive() & 32)
        ui->messageTextBrowser->append("Is not tracking");
}

void UserEvaluationPolaris::on_stopRecordingMeasurementsButton_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Stopping",
       "Do you realy want to stop recording? Previously tracked data will be moved to .backup file.",
       QMessageBox::Yes|QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        //stop trackingon_choosePhaseDropbox_currentIndexChanged
        //remove the current files
        this->m_UserEvaluationPipeline->stopTracking();
        this->m_UserEvaluationPipeline->closeCSVdataFile();
        int phase_csv = ui->choosePhaseDropbox->currentIndex() + 1;
        QString fn = QString::fromStdString(
                    this->m_UserEvaluationPipeline->composeCSVoutFileName(false, true));
        QString bfn = fn.left(fn.length()-4) + ".backup.csv";
        backup(phase_csv,
               fn,
               bfn);
        fn = QString::fromStdString(
                    this->m_UserEvaluationPipeline->composeCSVoutFileName(true, true));
        bfn = fn.left(fn.length()-4) + ".backup.csv";
        backup(phase_csv,
               fn,
               bfn);
        fn = QString::fromStdString(
                    this->m_UserEvaluationPipeline->composeContDataFileName(false));
        bfn = fn.left(fn.length()-4) + ".backup.csv";
        backup(phase_csv,
               fn,
               bfn);
        fn = QString::fromStdString(
                    this->m_UserEvaluationPipeline->composeContDataFileName(true));
        bfn = fn.left(fn.length()-4) + ".backup.csv";
        backup(phase_csv,
               fn,
               bfn);
        this->snapshotShortcut->setEnabled(false);
        ui->recordMeasurementButton->setEnabled(false);
        ui->stopRecordingMeasurementsButton->setEnabled(false);
        ui->recordingsButtonBox->setEnabled(true);
        ui->startRecordButton->setEnabled(true);
        this->startRecordingShortcut->setEnabled(true);
        ui->choosePhaseDropbox->setEnabled(true);
        ui->nextPhaseButton->setEnabled(true);

        this->snapshotCnt = 0;
        ui->messageTextBrowser->append("Broke up capturing");
    }
}

void UserEvaluationPolaris::on_nextPhaseButton_clicked()
{
    int i = ui->choosePhaseDropbox->currentIndex();
    if (++i < ui->choosePhaseDropbox->maxCount()) {
        ui->choosePhaseDropbox->setCurrentIndex(i);
        this->m_UserEvaluationPipeline->SetPhase(i);
        ui->messageTextBrowser->append("Next Phase is " +
                ui->choosePhaseDropbox->currentText());
    }
    else
        ui->messageTextBrowser->append("Last Phase completed, please save!");
}

void UserEvaluationPolaris::on_choosePhaseDropbox_activated(int index)
{
    this->m_UserEvaluationPipeline->SetPhase(index);
    ui->messageTextBrowser->append("Next Phase is " +
                ui->choosePhaseDropbox->currentText());
}

void UserEvaluationPolaris::on_recordingsButtonBox_accepted()
{
    if(no_records) {
        ui->messageTextBrowser->append("No records jet.");
        return;
    }
    // write out the participants file
    ui->messageTextBrowser->append("Saving measurements for Participant ID " +
                QString::number(ui->participantIDSpinner->value()));
    this->m_UserEvaluationPipeline->stopTracking();
    this->m_UserEvaluationPipeline->writeCSVdataFile();
    this->finished_phases.clear();
    this->cached_finished_phases.clear();
    ui->participantIDSpinner->setEnabled(true);
    ui->startEvaluationButton->setEnabled(true);
    ui->startRecordButton->setEnabled(false);
    this->startRecordingShortcut->setEnabled(false);
    ui->recordingsButtonBox->setEnabled(false);
    ui->recordMeasurementButton->setEnabled(false);
    ui->nextPhaseButton->setEnabled(false);
    ui->choosePhaseDropbox->setEnabled(false);
    ui->stopRecordingMeasurementsButton->setEnabled(false);
    no_records = true;
    ui->messageTextBrowser->append("Successfull!");
    // and append them
}

void UserEvaluationPolaris::on_recordingsButtonBox_rejected()
{
    if(no_records) {
        ui->choosePhaseDropbox->setEnabled(false);
        ui->startEvaluationButton->setEnabled(true);
        ui->participantIDSpinner->setEnabled(true);
        ui->recordingsButtonBox->setEnabled(false);
        ui->startRecordButton->setEnabled(false);
        this->startRecordingShortcut->setEnabled(false);
        ui->messageTextBrowser->append("No Records.");
        this->m_UserEvaluationPipeline->closeCSVdataFile();
        return;
    }
   // dissmiss all data currently taken for this participant
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "cancle",
       "Do you realy want to cancle? Previously tracked data will be removed.",
       QMessageBox::Yes|QMessageBox::No);
    if(reply == QMessageBox::Yes) {
        this->m_UserEvaluationPipeline->stopTracking();
        this->m_UserEvaluationPipeline->closeCSVdataFile();
        this->m_UserEvaluationPipeline->clearCSVdataFile();
        ui->participantIDSpinner->setEnabled(true);
        ui->startEvaluationButton->setEnabled(true);
        ui->startRecordButton->setEnabled(false);
        this->startRecordingShortcut->setEnabled(false);
        ui->recordingsButtonBox->setEnabled(false);
        ui->nextPhaseButton->setEnabled(false);
        ui->stopRecordingMeasurementsButton->setEnabled(false);
        ui->choosePhaseDropbox->setEnabled(false);
        ui->recordMeasurementButton->setEnabled(false);
    }
}

void UserEvaluationPolaris::on_chooseCSVDataPathButton_clicked()
{
    QString fileName = QFileDialog::getExistingDirectory(this, tr("Open Directory"),
                                                         "/",
                                                         QFileDialog::ShowDirsOnly);
    ui->CSVdataPathLineEdit->setText(fileName);
}

void UserEvaluationPolaris::on_chooseContDataPathButton_clicked()
{
    QString fileName = QFileDialog::getExistingDirectory(this, tr("Open Directory"),
                                                         "/",
                                                         QFileDialog::ShowDirsOnly);
    ui->contDataPathLineEdit->setText(fileName);
}

void UserEvaluationPolaris::on_choosePointerConfigFileButton_clicked()
{
    QUrl file = QFileDialog::getOpenFileUrl(this,
        tr("Open Registrationfile"), m_Configfilepath, tr("xml Files (*.xml)"));
    ui->pointerConfigFileLineEdit->setText(file.toLocalFile());
    m_Configfilepath = file.path();
}

void UserEvaluationPolaris::on_chooseObject1ConfigFileButton_clicked()
{
    QUrl file = QFileDialog::getOpenFileUrl(this,
        tr("Open Registrationfile"), m_Configfilepath, tr("xml Files (*.xml)"));
    ui->object1ConfigFileLineEdit->setText(file.toLocalFile());
    m_Configfilepath = file.path();
}

void UserEvaluationPolaris::on_chooseObject2ConfigFileButton_clicked()
{
    QUrl file = QFileDialog::getOpenFileUrl(this,
        tr("Open Registrationfile"), m_Configfilepath, tr("xml Files (*.xml)"));
    ui->object2ConfigFileLineEdit->setText(file.toLocalFile());
    m_Configfilepath = file.path();
}

void UserEvaluationPolaris::on_recordMeasurementButton_clicked()
{
    this->on_recordMeasurement();
}

void UserEvaluationPolaris::on_loadConfigButton_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this,
        tr("Open Configfile"), m_Configfilepath, tr("txt Files (*.txt)"));
    this->loadConfig(filename);
}

void UserEvaluationPolaris::on_saveConfigButton_clicked()
{
    QString filename = QFileDialog::getSaveFileName(this,
        tr("Save Configfile"), m_Configfilepath, tr("txt Files (*.txt)"));
    this->saveConfig(filename);
}

void UserEvaluationPolaris::change_num_snapshot(const QString &arg1)
{
    if(arg1.contains("Test")) {
        ui->messageTextBrowser->append("Testphase: 10 Snapshots");
        this->num_snapshot = 10;
    } else if(arg1.contains("Train")) {
        ui->messageTextBrowser->append("Trainphase: 3 Snapshot");
        this->num_snapshot = 3;
    } else {
        ui->messageTextBrowser->append("Unknown Phase name: 10 Snapshots");
        this->num_snapshot = 10;
    }
    int cur_phase = ui->choosePhaseDropbox->currentIndex();
    bool phase_done = this->finished_phases.find(cur_phase) != this->finished_phases.end();
    ui->startRecordButton->setEnabled(!phase_done);
    this->startRecordingShortcut->setEnabled(!phase_done);
    if(phase_done) {
        ui->messageTextBrowser->append("Phase allready done please move files");
    }
}

void UserEvaluationPolaris::on_choosePhaseDropbox_currentIndexChanged(const QString &arg1)
{
    change_num_snapshot(arg1);
}
