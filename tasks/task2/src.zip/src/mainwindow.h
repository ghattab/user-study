#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QShortcut>
#include <PolarisObject.h>
#include <SceneUpdatePipeline.h>
#include <UserEvaluationPipeline.h>
#include "evaluationrecord.h"

namespace Ui {

class MainWindow;
}

class UserEvaluationPolaris : public QMainWindow
{
    Q_OBJECT

public:
    explicit UserEvaluationPolaris(QWidget *parent = 0);
    ~UserEvaluationPolaris();


private slots:

    //PARTICIPANT
    void on_startEvaluationButton_clicked();
    void on_choosePhaseDropbox_activated(int index);
    void on_startRecordButton_clicked();
    void on_nextPhaseButton_clicked();
    void on_recordMeasurement();
    void on_startRecording();

    void on_recordingsButtonBox_accepted();
    void on_recordingsButtonBox_rejected();

    void on_recordMeasurementButton_clicked();
    //SETUP
    //Polaris
    //void on_resetButton_clicked();
    void on_connectButton_clicked();

    //Polaris with Ethernet
    void on_chooseEthernetRadioButton_clicked();

    //Polaris with Serial
    void on_chooseSerialRadioButton_clicked();

    //Data
    void on_chooseCSVDataPathButton_clicked();
    void on_chooseContDataPathButton_clicked();
    void on_choosePointerConfigFileButton_clicked();
    void on_chooseObject1ConfigFileButton_clicked();
    void on_chooseObject2ConfigFileButton_clicked();

    void update_igstk();

    void on_loadConfigButton_clicked();

    void on_saveConfigButton_clicked();

    void on_stopRecordingMeasurementsButton_clicked();

    void on_choosePhaseDropbox_currentIndexChanged(const QString &arg1);

private:
    void loadConfig(QString config_fn);
    void saveConfig(QString config_fn);
    void change_num_snapshot(const QString &arg1);

    const QString config = ".config.txt";
    const QString DEFAULT_POLARIS_HOSTNAME = "P9-00686";
    const int DEFAULT_POLARIS_PORT = 8765;
    const int DEFAULT_POLARIS_SERIAL_PORT = 0;

    Ui::MainWindow *ui;
    QShortcut* snapshotShortcut;
    QShortcut* startRecordingShortcut;
    bool snapshot;
    QTimer *timer;
    int snapshotCnt;
    int num_snapshot = 10 ;
    //Attention phase index from 0
    std::set<int> finished_phases;
    std::set<int> cached_finished_phases;

    MediAssist::PolarisObject::Pointer m_Polaris;
    MediAssist::SceneUpdatePipeline::Pointer m_SceneUpdate;
    MediAssist::UserEvaluationPipeline::Pointer m_UserEvaluationPipeline;
    std::string m_IDPointer;
    QString m_Configfilepath;

    void backup(int phase, QString data_fn , QString backup_fn);

    igstk::Object::LoggerType::Pointer logger;
    itk::StdStreamLogOutput::Pointer logOutput;
    std::ofstream loggerFile;

    bool no_records = false;
};

#endif // MAINWINDOW_H
