#ifndef EVALUATIONRECORD_H
#define EVALUATIONRECORD_H

#include <vector>
#include <QDateTime>
#include <QTime>
#include <cv.h>

using namespace std;
using namespace cv;
class Measurement
{
public:
    Measurement(Vec3f coord,
                 Vec4f quad,
                 QDateTime date,
                 int phase,
                 QTime elapsed_time);
    Vec3f m_Coord;
    Vec4f m_Quad;
    QDateTime m_Date;
    int m_Phase;
    QTime m_Ellapsed_time;
};

class EvaluationRecord
{
public:
    EvaluationRecord(int id);
    int get_ID();
    Measurement *get_meassurment(int phase);
    bool push_meassurment(Measurement *m);
private:
    vector<Measurement*> *measures;
    int m_ID;
};

#endif // EVALUATIONRECORD_H
