#include "tools.h"

#include <iostream>
#include <string>
#include <vector>
#include <QImage>


using namespace std;

Tools::Tools():polaris(nullptr),
    registered_handles(),
    polaris_inited(false),
    message("")
{

}

bool Tools::polaris_connect_ethernet(const std::string hostname, int port)
{
    if(hostname == "")
        return false;
    polaris = ndiOpenNetwork(hostname.c_str(), POLARIS_PORT);
    return polaris != nullptr;
    set_message("polaris ethernet connect");
}

bool Tools::polaris_connect_com()
{
    char* device = nullptr;
    for (int i = 0; i < 4; i++) {
        device = ndiSerialDeviceName(i);
        if (device != nullptr) {
            break;
        }
    }
    if(ndiSerialProbe(device, true) != NDI_OKAY) {
        return false;
    }
    polaris = ndiOpenSerial(device);
    return polaris != nullptr;
    set_message("polaris serial connect");
}

void Tools::polaris_init()
{
    ndiINIT(polaris);
    this->polaris_inited = true;
    set_message("polaris init");
}

void Tools::polaris_beep()
{
    ndiBEEP(polaris, 1);
    set_message("beep");
}

int Tools::polaris_load_roms()
{
    vector<std::string> fnames{
        "8700338.rom",
        "8700339.rom",
        "8700340.rom"
    };
    for(auto&& fn = fnames.begin(); fn != fnames.end(); ++fn){
        PolarisHandle handle(*fn);
        ndiPHRQ(polaris, "********", "*", "1", "00", "**");
        int ph = ndiGetPHRQHandle(polaris);
        //cout << "Offered Port: " << ph << endl;
        string path = "sroms/" + *fn;
        if(ndiPVWRFromFile(polaris, ph, const_cast<char *>(path.c_str())) != NDI_OKAY)
        {
            handle.registered = false;
            if (message != "")
                message += "\n";
            message += ndiGetError(polaris);
        }
        else
            handle.registered = true;
        registered_handles.push_back(handle);
    }
    ndiPHSR(polaris, NDI_UNINITIALIZED_HANDLES);
    //cout << "handles to be enabled and init: " << ndiGetPHSRNumberOfHandles(polaris) << endl;
    for(int i = 0; i < ndiGetPHSRNumberOfHandles(polaris); i++) {
        // we don't check registered_handles
        ndiPINIT(polaris, ndiGetPHSRHandle(polaris, i));
        ndiPENA(polaris, ndiGetPHSRHandle(polaris, i), NDI_DYNAMIC);

    }
    ndiPHSR(polaris, NDI_ENABLED_HANDLES);
    for (int i = 0; i < ndiGetPHSRNumberOfHandles(polaris); i++) {
        registered_handles[i].id = ndiGetPHSRHandle(polaris, i);
    }
    set_message("polaris load roms and init/enable");
    return NDI_OKAY;
}

void Tools::polaris_laser()
{
    if(this->polaris_inited)
        ndiCommand(polaris, "SET Param.Laser.Laser Status=1");
}

void Tools::polaris_start_tracking()
{
    ndiTSTART(polaris);
    set_message("polaris start tracking");
}

bool Tools::update(bool read_polaris)
{
    if(polaris != nullptr && this->polaris_inited && read_polaris) {
        ndiTX(polaris, 0x1803);
    }

    if(polaris != nullptr && this->polaris_inited && read_polaris) {
        double trans[8] = {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
        for(auto ph = registered_handles.begin(); ph != registered_handles.end(); ph++){
            ndiGetTXTransform(polaris,
                              ph->id,
                              trans);
            for(int i = 0; i < 8; i++)
                ph->coords[i] = trans[i];
        }
    }

    return true;
}

const std::string Tools::get_messages()
{
    std::string ret(message);
    message = "";
    return ret;
}

void Tools::set_message(std::string mess)
{
    if (message != "")
        message += "\n";
    message += mess;

}

PolarisHandle::PolarisHandle(std::string fname1):
    fname(fname1),
    name(""),
    registered(false),
    id(-1),
    coords{0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0}
{}
