#ifndef TOOLS_H
#define TOOLS_H

#include <vector>
#include <string>

#include <ndicapi.h>

class PolarisHandle
{
public:
    PolarisHandle(std::string fname1);
    std::string fname;
    std::string name;
    bool registered;
    int id;
    double coords[8];
};

class Tools
{
public:
    static const std::string DEFAULT_HOSTNAME;
    static const int DEFAULT_PORT;

public:
    Tools();
    bool polaris_connect_ethernet(const std::string, int port);
    bool polaris_connect_com();
    void polaris_init();
    void polaris_beep();
    void polaris_laser();
    int polaris_load_roms();
    void polaris_start_tracking();
    bool update(bool read_polaris);
    const std::string get_polaris_coords_str();
    const std::string get_messages();


private:
    void set_message(std::string mess);

    ndicapi* polaris;
    std::vector<PolarisHandle> registered_handles;
    bool polaris_inited;
};

#endif // TOOLS_H
