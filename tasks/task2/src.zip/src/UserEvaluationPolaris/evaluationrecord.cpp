#include "evaluationrecord.h"


using namespace std;

Meassurement::Meassurement(Vec3f coord,
             Vec4f quad,
             QDateTime date,
             int phase,
             QTime elapsed_time):
    m_Coord(coord),
    m_Quad(quad),
    m_Date(date),
    m_Phase(phase),
    m_Ellapsed_time(elapsed_time)
{

}

EvaluationRecord::EvaluationRecord(int id):
    m_ID(id)
{
    meassuremnts = new vector<Meassurement*>();
}

int EvaluationRecord::get_ID()
{
	return m_ID;
}

Meassurement *EvaluationRecord::get_meassurment(int phase)
{
    auto m = std::find_if(meassuremnts->begin(),
            meassuremnts->end(),
            [phase](Meassurement *x){return phase == x->m_Phase;});
    return m != meassuremnts->end() ? *m : nullptr;
}
bool EvaluationRecord::push_meassurment(Meassurement *m){

}
