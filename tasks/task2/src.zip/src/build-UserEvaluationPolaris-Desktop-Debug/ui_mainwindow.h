/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QSpinBox>
#include <QtGui/QStatusBar>
#include <QtGui/QTabWidget>
#include <QtGui/QTextBrowser>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include <TrackerVisibilityWidget.h>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionConnect;
    QAction *actionClose;
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget;
    QWidget *participantTab;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_2;
    QLabel *participantIDLabel;
    QSpinBox *participantIDSpinner;
    QPushButton *startEvaluationButton;
    QComboBox *choosePhaseDropbox;
    QPushButton *startRecordButton;
    QPushButton *recordMeassurementButton;
    QPushButton *nextPhaseButton;
    QDialogButtonBox *recordingsButtonBox;
    QWidget *setupTab;
    QWidget *widget;
    QVBoxLayout *verticalLayout_7;
    QPushButton *resetButton;
    QPushButton *connectButton;
    QHBoxLayout *chooseCommunicationHorizontalLayout;
    QVBoxLayout *ethernetVerticalLayout;
    QRadioButton *chooseEthernetRadioButton;
    QHBoxLayout *ethernetPortHorizontalLayout;
    QLabel *ethernetPortLabel;
    QSpinBox *ethernetPortSpinBox;
    QHBoxLayout *ethernetHostnameHorizontalLayout;
    QLabel *ethernetHostnameLabel;
    QLineEdit *ethernetHostnameLineEdit;
    QVBoxLayout *SerialVerticalLayout;
    QRadioButton *chooseSerialRadioButton;
    QHBoxLayout *serialPortHorizontalLayout;
    QLabel *serialPortLabel;
    QSpinBox *serialPortSpinBox;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_6;
    QLineEdit *pointerConfigFileLineEdit;
    QPushButton *choosePointerConfigFileButton;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_7;
    QLineEdit *object1ConfigFileLineEdit;
    QPushButton *chooseObject1ConfigFileButton;
    QHBoxLayout *horizontalLayout;
    QLabel *label_9;
    QLineEdit *object2ConfigFileLineEdit;
    QPushButton *chooseObject2ConfigFileButton;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_8;
    QLineEdit *CSVdataPathLineEdit;
    QPushButton *chooseCSVDataPathButton;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_10;
    QLineEdit *contDataPathLineEdit;
    QPushButton *chooseContDataPathButton;
    QTextBrowser *messageTextBrowser;
    QTrackerVisibilityWidget *visibilityWidget;
    QHBoxLayout *horizontalLayout_3;
    QMenuBar *menuBar;
    QMenu *menuTraining;
    QStatusBar *statusBar;
    QButtonGroup *chooseCommunicationTypeButtonGroup;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(934, 901);
        actionConnect = new QAction(MainWindow);
        actionConnect->setObjectName(QString::fromUtf8("actionConnect"));
        actionClose = new QAction(MainWindow);
        actionClose->setObjectName(QString::fromUtf8("actionClose"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        participantTab = new QWidget();
        participantTab->setObjectName(QString::fromUtf8("participantTab"));
        participantTab->setMinimumSize(QSize(0, 190));
        verticalLayoutWidget = new QWidget(participantTab);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(0, 0, 911, 365));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        participantIDLabel = new QLabel(verticalLayoutWidget);
        participantIDLabel->setObjectName(QString::fromUtf8("participantIDLabel"));

        horizontalLayout_2->addWidget(participantIDLabel);

        participantIDSpinner = new QSpinBox(verticalLayoutWidget);
        participantIDSpinner->setObjectName(QString::fromUtf8("participantIDSpinner"));
        participantIDSpinner->setMaximum(499);

        horizontalLayout_2->addWidget(participantIDSpinner);

        startEvaluationButton = new QPushButton(verticalLayoutWidget);
        startEvaluationButton->setObjectName(QString::fromUtf8("startEvaluationButton"));

        horizontalLayout_2->addWidget(startEvaluationButton);


        verticalLayout_3->addLayout(horizontalLayout_2);

        choosePhaseDropbox = new QComboBox(verticalLayoutWidget);
        choosePhaseDropbox->setObjectName(QString::fromUtf8("choosePhaseDropbox"));
        choosePhaseDropbox->setEnabled(false);

        verticalLayout_3->addWidget(choosePhaseDropbox);

        startRecordButton = new QPushButton(verticalLayoutWidget);
        startRecordButton->setObjectName(QString::fromUtf8("startRecordButton"));
        startRecordButton->setEnabled(false);

        verticalLayout_3->addWidget(startRecordButton);

        recordMeassurementButton = new QPushButton(verticalLayoutWidget);
        recordMeassurementButton->setObjectName(QString::fromUtf8("recordMeassurementButton"));
        recordMeassurementButton->setEnabled(false);

        verticalLayout_3->addWidget(recordMeassurementButton);

        nextPhaseButton = new QPushButton(verticalLayoutWidget);
        nextPhaseButton->setObjectName(QString::fromUtf8("nextPhaseButton"));
        nextPhaseButton->setEnabled(false);

        verticalLayout_3->addWidget(nextPhaseButton);

        recordingsButtonBox = new QDialogButtonBox(verticalLayoutWidget);
        recordingsButtonBox->setObjectName(QString::fromUtf8("recordingsButtonBox"));
        recordingsButtonBox->setEnabled(false);
        recordingsButtonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout_3->addWidget(recordingsButtonBox);

        tabWidget->addTab(participantTab, QString());
        setupTab = new QWidget();
        setupTab->setObjectName(QString::fromUtf8("setupTab"));
        widget = new QWidget(setupTab);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(17, 12, 871, 341));
        verticalLayout_7 = new QVBoxLayout(widget);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        resetButton = new QPushButton(widget);
        resetButton->setObjectName(QString::fromUtf8("resetButton"));

        verticalLayout_7->addWidget(resetButton);

        connectButton = new QPushButton(widget);
        connectButton->setObjectName(QString::fromUtf8("connectButton"));

        verticalLayout_7->addWidget(connectButton);

        chooseCommunicationHorizontalLayout = new QHBoxLayout();
        chooseCommunicationHorizontalLayout->setSpacing(6);
        chooseCommunicationHorizontalLayout->setObjectName(QString::fromUtf8("chooseCommunicationHorizontalLayout"));
        ethernetVerticalLayout = new QVBoxLayout();
        ethernetVerticalLayout->setSpacing(6);
        ethernetVerticalLayout->setObjectName(QString::fromUtf8("ethernetVerticalLayout"));
        chooseEthernetRadioButton = new QRadioButton(widget);
        chooseCommunicationTypeButtonGroup = new QButtonGroup(MainWindow);
        chooseCommunicationTypeButtonGroup->setObjectName(QString::fromUtf8("chooseCommunicationTypeButtonGroup"));
        chooseCommunicationTypeButtonGroup->addButton(chooseEthernetRadioButton);
        chooseEthernetRadioButton->setObjectName(QString::fromUtf8("chooseEthernetRadioButton"));

        ethernetVerticalLayout->addWidget(chooseEthernetRadioButton);

        ethernetPortHorizontalLayout = new QHBoxLayout();
        ethernetPortHorizontalLayout->setSpacing(6);
        ethernetPortHorizontalLayout->setObjectName(QString::fromUtf8("ethernetPortHorizontalLayout"));
        ethernetPortLabel = new QLabel(widget);
        ethernetPortLabel->setObjectName(QString::fromUtf8("ethernetPortLabel"));

        ethernetPortHorizontalLayout->addWidget(ethernetPortLabel);

        ethernetPortSpinBox = new QSpinBox(widget);
        ethernetPortSpinBox->setObjectName(QString::fromUtf8("ethernetPortSpinBox"));
        ethernetPortSpinBox->setMinimum(1);
        ethernetPortSpinBox->setMaximum(10000);

        ethernetPortHorizontalLayout->addWidget(ethernetPortSpinBox);


        ethernetVerticalLayout->addLayout(ethernetPortHorizontalLayout);

        ethernetHostnameHorizontalLayout = new QHBoxLayout();
        ethernetHostnameHorizontalLayout->setSpacing(6);
        ethernetHostnameHorizontalLayout->setObjectName(QString::fromUtf8("ethernetHostnameHorizontalLayout"));
        ethernetHostnameLabel = new QLabel(widget);
        ethernetHostnameLabel->setObjectName(QString::fromUtf8("ethernetHostnameLabel"));

        ethernetHostnameHorizontalLayout->addWidget(ethernetHostnameLabel);

        ethernetHostnameLineEdit = new QLineEdit(widget);
        ethernetHostnameLineEdit->setObjectName(QString::fromUtf8("ethernetHostnameLineEdit"));

        ethernetHostnameHorizontalLayout->addWidget(ethernetHostnameLineEdit);


        ethernetVerticalLayout->addLayout(ethernetHostnameHorizontalLayout);


        chooseCommunicationHorizontalLayout->addLayout(ethernetVerticalLayout);

        SerialVerticalLayout = new QVBoxLayout();
        SerialVerticalLayout->setSpacing(6);
        SerialVerticalLayout->setObjectName(QString::fromUtf8("SerialVerticalLayout"));
        chooseSerialRadioButton = new QRadioButton(widget);
        chooseCommunicationTypeButtonGroup->addButton(chooseSerialRadioButton);
        chooseSerialRadioButton->setObjectName(QString::fromUtf8("chooseSerialRadioButton"));

        SerialVerticalLayout->addWidget(chooseSerialRadioButton);

        serialPortHorizontalLayout = new QHBoxLayout();
        serialPortHorizontalLayout->setSpacing(6);
        serialPortHorizontalLayout->setObjectName(QString::fromUtf8("serialPortHorizontalLayout"));
        serialPortLabel = new QLabel(widget);
        serialPortLabel->setObjectName(QString::fromUtf8("serialPortLabel"));

        serialPortHorizontalLayout->addWidget(serialPortLabel);

        serialPortSpinBox = new QSpinBox(widget);
        serialPortSpinBox->setObjectName(QString::fromUtf8("serialPortSpinBox"));

        serialPortHorizontalLayout->addWidget(serialPortSpinBox);


        SerialVerticalLayout->addLayout(serialPortHorizontalLayout);


        chooseCommunicationHorizontalLayout->addLayout(SerialVerticalLayout);


        verticalLayout_7->addLayout(chooseCommunicationHorizontalLayout);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_6 = new QLabel(widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_4->addWidget(label_6);

        pointerConfigFileLineEdit = new QLineEdit(widget);
        pointerConfigFileLineEdit->setObjectName(QString::fromUtf8("pointerConfigFileLineEdit"));

        horizontalLayout_4->addWidget(pointerConfigFileLineEdit);

        choosePointerConfigFileButton = new QPushButton(widget);
        choosePointerConfigFileButton->setObjectName(QString::fromUtf8("choosePointerConfigFileButton"));

        horizontalLayout_4->addWidget(choosePointerConfigFileButton);


        verticalLayout_7->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_7 = new QLabel(widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_5->addWidget(label_7);

        object1ConfigFileLineEdit = new QLineEdit(widget);
        object1ConfigFileLineEdit->setObjectName(QString::fromUtf8("object1ConfigFileLineEdit"));

        horizontalLayout_5->addWidget(object1ConfigFileLineEdit);

        chooseObject1ConfigFileButton = new QPushButton(widget);
        chooseObject1ConfigFileButton->setObjectName(QString::fromUtf8("chooseObject1ConfigFileButton"));

        horizontalLayout_5->addWidget(chooseObject1ConfigFileButton);


        verticalLayout_7->addLayout(horizontalLayout_5);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_9 = new QLabel(widget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout->addWidget(label_9);

        object2ConfigFileLineEdit = new QLineEdit(widget);
        object2ConfigFileLineEdit->setObjectName(QString::fromUtf8("object2ConfigFileLineEdit"));

        horizontalLayout->addWidget(object2ConfigFileLineEdit);

        chooseObject2ConfigFileButton = new QPushButton(widget);
        chooseObject2ConfigFileButton->setObjectName(QString::fromUtf8("chooseObject2ConfigFileButton"));

        horizontalLayout->addWidget(chooseObject2ConfigFileButton);


        verticalLayout_7->addLayout(horizontalLayout);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_8 = new QLabel(widget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_6->addWidget(label_8);

        CSVdataPathLineEdit = new QLineEdit(widget);
        CSVdataPathLineEdit->setObjectName(QString::fromUtf8("CSVdataPathLineEdit"));

        horizontalLayout_6->addWidget(CSVdataPathLineEdit);

        chooseCSVDataPathButton = new QPushButton(widget);
        chooseCSVDataPathButton->setObjectName(QString::fromUtf8("chooseCSVDataPathButton"));

        horizontalLayout_6->addWidget(chooseCSVDataPathButton);


        verticalLayout_7->addLayout(horizontalLayout_6);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        label_10 = new QLabel(widget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_8->addWidget(label_10);

        contDataPathLineEdit = new QLineEdit(widget);
        contDataPathLineEdit->setObjectName(QString::fromUtf8("contDataPathLineEdit"));

        horizontalLayout_8->addWidget(contDataPathLineEdit);

        chooseContDataPathButton = new QPushButton(widget);
        chooseContDataPathButton->setObjectName(QString::fromUtf8("chooseContDataPathButton"));

        horizontalLayout_8->addWidget(chooseContDataPathButton);


        verticalLayout_7->addLayout(horizontalLayout_8);

        tabWidget->addTab(setupTab, QString());

        verticalLayout->addWidget(tabWidget);

        messageTextBrowser = new QTextBrowser(centralWidget);
        messageTextBrowser->setObjectName(QString::fromUtf8("messageTextBrowser"));

        verticalLayout->addWidget(messageTextBrowser);

        visibilityWidget = new QTrackerVisibilityWidget(centralWidget);
        visibilityWidget->setObjectName(QString::fromUtf8("visibilityWidget"));
        visibilityWidget->setMinimumSize(QSize(510, 44));
        visibilityWidget->setFrameShape(QFrame::StyledPanel);
        visibilityWidget->setFrameShadow(QFrame::Raised);

        verticalLayout->addWidget(visibilityWidget);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));

        verticalLayout->addLayout(horizontalLayout_3);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 934, 20));
        menuTraining = new QMenu(menuBar);
        menuTraining->setObjectName(QString::fromUtf8("menuTraining"));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuTraining->menuAction());
        menuTraining->addAction(actionClose);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "User Evaluation for Polaris", 0, QApplication::UnicodeUTF8));
        actionConnect->setText(QApplication::translate("MainWindow", "Connect", 0, QApplication::UnicodeUTF8));
        actionClose->setText(QApplication::translate("MainWindow", "&Close", 0, QApplication::UnicodeUTF8));
        participantIDLabel->setText(QApplication::translate("MainWindow", "Participant ID", 0, QApplication::UnicodeUTF8));
        startEvaluationButton->setText(QApplication::translate("MainWindow", "Start Evaluation", 0, QApplication::UnicodeUTF8));
        choosePhaseDropbox->clear();
        choosePhaseDropbox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Liver 1", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Liver 2", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Liver 3", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Pyramide 1", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Pyramide 2", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "Pyramide 3", 0, QApplication::UnicodeUTF8)
        );
        startRecordButton->setText(QApplication::translate("MainWindow", "Start 10 Recordings", 0, QApplication::UnicodeUTF8));
        recordMeassurementButton->setText(QApplication::translate("MainWindow", "record Measurement", 0, QApplication::UnicodeUTF8));
        nextPhaseButton->setText(QApplication::translate("MainWindow", "Next Phase", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(participantTab), QApplication::translate("MainWindow", "Participant", 0, QApplication::UnicodeUTF8));
        resetButton->setText(QApplication::translate("MainWindow", "Reset", 0, QApplication::UnicodeUTF8));
        connectButton->setText(QApplication::translate("MainWindow", "Connect", 0, QApplication::UnicodeUTF8));
        chooseEthernetRadioButton->setText(QApplication::translate("MainWindow", "Ethernet Co&mmunication", 0, QApplication::UnicodeUTF8));
        ethernetPortLabel->setText(QApplication::translate("MainWindow", "Port", 0, QApplication::UnicodeUTF8));
        ethernetHostnameLabel->setText(QApplication::translate("MainWindow", "Hostname", 0, QApplication::UnicodeUTF8));
        chooseSerialRadioButton->setText(QApplication::translate("MainWindow", "Seria&l Communication", 0, QApplication::UnicodeUTF8));
        serialPortLabel->setText(QApplication::translate("MainWindow", "Port", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("MainWindow", "Pointer Config", 0, QApplication::UnicodeUTF8));
        choosePointerConfigFileButton->setText(QApplication::translate("MainWindow", "Choose File", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("MainWindow", "Object1 Config", 0, QApplication::UnicodeUTF8));
        chooseObject1ConfigFileButton->setText(QApplication::translate("MainWindow", "Choose File", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("MainWindow", "Object2 Config", 0, QApplication::UnicodeUTF8));
        chooseObject2ConfigFileButton->setText(QApplication::translate("MainWindow", "Choose File", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("MainWindow", "Data CSV Path", 0, QApplication::UnicodeUTF8));
        chooseCSVDataPathButton->setText(QApplication::translate("MainWindow", "Choose File", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("MainWindow", "Choose continous Data path", 0, QApplication::UnicodeUTF8));
        chooseContDataPathButton->setText(QApplication::translate("MainWindow", "Choose Path", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(setupTab), QApplication::translate("MainWindow", "Setup", 0, QApplication::UnicodeUTF8));
        menuTraining->setTitle(QApplication::translate("MainWindow", "Trai&ning", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
